const express = require('express');
const router = express.Router();

const audio = require("./Audio/routes")

// ====================================================================
//                          Openai Whisper Router(s)
// ====================================================================

router.use("audio" , audio)

// ====================================================================

module.exports = router;
