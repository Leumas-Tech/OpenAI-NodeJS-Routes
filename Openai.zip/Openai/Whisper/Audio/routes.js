const express = require('express');
const router = express.Router();

const controller = require("./controllers.js")

// ====================================================================
//                           Whisper Audio Router(s)
// ====================================================================

router.post('/create-transcription', controller.CreateTranscription);
router.post('/create-translation', controller.CreateTranslation);

// ====================================================================

module.exports = router;
