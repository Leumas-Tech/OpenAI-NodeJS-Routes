const {openai} = require("../../openai")

exports.CreateTranscription = async (req, res) => {
    try {
        // Check if the file was uploaded
        if (!req.files || Object.keys(req.files).length === 0) {
            return res.status(400).send('No files were uploaded.');
        }

        // Get the uploaded file
        let audioFile = req.files.file;  // Assuming "file" is the name of the field in your form.

        const { model, prompt, response_format, temperature, language } = req.body;

        // Validate model, as it's required
        if (!model) {
            return res.status(400).send('Model is required.');
        }

        // Create a transcription
        const transcription = await openai.audio.transcriptions.create({
            file: fs.createReadStream(audioFile.tempFilePath),
            model,
            prompt,
            response_format,
            temperature,
            language
        });

        // Send the response
        res.status(200).send(transcription.text);

    } catch (err) {
        console.error("Error creating transcription:", err.message);
        res.status(500).send({
            message: "Error creating transcription"
        });
    }
}





exports.CreateTranslation = async (req, res) => {
    try {
        // Check if the file was uploaded
        if (!req.files || Object.keys(req.files).length === 0) {
            return res.status(400).send('No files were uploaded.');
        }

        // Get the uploaded file
        let audioFile = req.files.file;  // Assuming "file" is the name of the field in your form.

        // Ensure the required model is provided (in this case "whisper-1")
        const model = req.body.model || "whisper-1";

        // Create a translation
        const translationResponse = await openai.createTranslation(
            fs.createReadStream(audioFile.tempFilePath),
            model
        );

        // Send the response
        res.status(200).send(translationResponse.data);

    } catch (err) {
        console.error("Error creating translation:", err.message);
        res.status(500).send({
            message: "Error creating translation"
        });
    }
};