const express = require('express');
const router = express.Router();

const images = require("./Images/routes")

// ====================================================================
//                          Openai Dalle Router(s)
// ====================================================================

router.use("/images" , images)

// ====================================================================

module.exports = router;
