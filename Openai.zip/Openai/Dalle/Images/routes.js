const express = require('express');
const router = express.Router();

const controller = require("./controllers")

const multer = require('multer');
const upload = multer(); 

// ====================================================================
//                           DALLE Images Router(s)
// ====================================================================

router.post('/generate', controller.CreateImage);
router.post('/edit', upload.fields([{name: 'image'}, {name: 'mask'}]), controller.EditImage);
router.post('/variation', upload.single('image'), controller.CreateImageVariation);

// ====================================================================

module.exports = router;
