const {openai} = require("../../openai")
const fs = require('fs');

exports.CreateImage = async (req, res) => {
    const { prompt, n, size } = req.body;  // Destructure properties from req.body
    console.log("Creating an image")
    try {
        const image = await openai.images.generate({
            prompt: prompt,
            n: n,
            size: size
        });
        console.log("Here is your image ", image)
        res.status(200).send(image.data);
    } catch (err) {
        console.error("Error creating image:", err.message);
        res.status(500).send({ message: "Error creating image" });
    }
};



exports.EditImage = async (req, res) => {
    if (!req.files || !req.files.image || !req.files.mask) {
        return res.status(400).send({ message: "Image and mask files are required!" });
    }
    const prompt = req.body.prompt;

    try {
        const image = await openai.images.edit({
            image: req.files.image[0].buffer,
            mask: req.files.mask[0].buffer,
            prompt
        });

        res.status(200).send(image.data);
    } catch (err) {
        console.error("Error editing image:", err.message);
        res.status(500).send({ message: "Error editing image" });
    }
};


exports.CreateImageVariation = async (req, res) => {
    if (!req.file) {
        return res.status(400).send({ message: "Image file is required!" });
    } else {
        console.log("we got da file")
    }

    try {
        const imageVariationResponse = await openai.images.createVariation({
            image: req.file.buffer
        });

        if (imageVariationResponse.status === 200) {
            res.status(200).send(imageVariationResponse.data);
        } else {
            console.error("Error from OpenAI API:", imageVariationResponse.data);
            res.status(500).send({ message: "Error creating image variation" });
        }
    } catch (err) {
        console.error("Error creating image variation:", err.message);
        res.status(500).send({ message: "Error creating image variation" });
    }
};