const express = require('express');
const router = express.Router();

const chatGpt = require("./ChatGPT/routes");
const dalle = require("./Dalle/routes");
const whisper = require("./Whisper/routes")

// ====================================================================
//                          Openai Router(s)
// ====================================================================

router.use("/chatgpt" , chatGpt)
router.use("/dalle" , dalle)
router.use("/whisper" , whisper)

// ====================================================================

module.exports = router;
