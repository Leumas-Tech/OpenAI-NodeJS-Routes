const express = require('express');
const router = express.Router();

const controller = require("./controllers")

// ====================================================================
//                           ChatGPT Fine Tuning Router(s)
// ====================================================================

router.post('/create-finetune', controller.CreateFineTuneModel);
router.post('/create-finetune-job', controller.CreateFineTuneJob);
router.post('/use-finetuned-model', controller.UseFineTunedModel);
router.get('/list-finetunes', controller.ListFineTunes);  // Considered as a GET request since it's listing resources.
// router.get('/fineTuningJobs/:fineTuneId', controller.RetrieveFineTuneJob);

router.get('/finetune-status', controller.FineTimeStatus); // Considered as a GET request since it's getting a status.
router.get('/events-from-finetuning-job', controller.EventsFromFineTuningJob); // GET request for fetching events.
router.delete('/delete-finetune', controller.DeleteFineTune); // DELETE request for deleting a model.
router.post('/fineTuningJobs/:fineTuneId/cancel', controller.CancelFineTuneJob);

// ====================================================================

module.exports = router;
