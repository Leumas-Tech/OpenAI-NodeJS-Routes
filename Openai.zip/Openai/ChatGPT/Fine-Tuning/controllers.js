const {openai} = require("../../openai")

exports.CreateFineTuneModel = async (req, res) => {
    const trainingFile = req.body.training_file || "file-abc123"; // Default to 'file-abc123' if no training file is provided
    const modelToFineTune = req.body.model || "gpt-3.5-turbo"; // Default to 'gpt-3.5-turbo' if no model is specified

    try {
        const fineTuneResult = await openai.fineTuning.jobs.create({
            training_file: trainingFile,
            model: modelToFineTune
        });

        // Handle the response as required
        res.status(200).json({
            success: true,
            message: "Fine-tuning job created successfully!",
            data: fineTuneResult
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: "Failed to create fine-tuning job.",
            error: err.message
        });
    }
}
exports.CreateFineTuneJob = async (req,res) => {
    const trainingFile = req.body.training_file;  // Using snake_case to match the request body format

    if (!trainingFile) {
        return res.status(400).send({
            message: "training_file is required!"
        });
    }

    try {
        const fineTuneResponse = await openai.fineTuning.jobs.create({
            training_file: trainingFile
        });

        // Send the fine tuning response from OpenAI back to your client
        res.status(200).send(fineTuneResponse);

    } catch (err) {
        console.error("Error with fine tuning model creation:", err.message);
        res.status(500).send({
            message: "Error with fine tuning model creation"
        });
    }
}
exports.UseFineTunedModel = async (req,res) => {
    const FineTune = req.body.FineTuneId
    try{
        completion = openai.ChatCompletion.create(
            model="ft:gpt-3.5-turbo:my-org:custom_suffix:id",
            messages=[
              {"role": "system", "content": "You are a helpful assistant."},
              {"role": "user", "content": "Hello!"}
            ]
          )
          
          print(completion.choices[0].message)
    }catch(err){
        
    }
}
exports.ListFineTunes = async (req,res) => {
    const RequestNumber = req.body.limit || 10
    try{
        // # List 10 fine-tuning jobs
    openai.FineTuningJob.list(limit=RequestNumber)
    }catch(err){
        
    }
}
exports.FineTimeStatus = async (req,res) => {
    const FineTune = req.body.FineTuneId
    try{
        // # Retrieve the state of a fine-tune
openai.FineTuningJob.retrieve(`${FineTune}`) 
    }catch(err){
        
    }
}
exports.EventsFromFineTuningJob = async (req,res) => {
    const FineTune = req.body.FineTuneId
    const RequestNumber = req.body.limit || 10
    try{
        // # List up to 10 events from a fine-tuning job
        openai.FineTuningJob.list_events(id=`${FineTune}`, limit=RequestNumber)
    }catch(err){
        
    }
}
exports.DeleteFineTune = async (req,res) => {
    const FineTune = req.body.FineTuneId
    try{
        openai.Model.delete(`${FineTune}`) 
    }catch(err){

    }

}
exports.CancelFineTuneJob = async (req, res) => {
    const fineTuneId = req.params.fineTuneId;

    if (!fineTuneId) {
        return res.status(400).send({
            message: "FineTuneId is required as a path parameter!"
        });
    }

    try {
        const fineTuneResponse = await openai.fineTuning.jobs.cancel(fineTuneId);

        // Send the cancellation response from OpenAI back to your client
        res.status(200).send(fineTuneResponse);

    } catch (err) {
        console.error("Error cancelling fine tuning job:", err.message);
        res.status(500).send({
            message: "Error cancelling fine tuning job"
        });
    }
};