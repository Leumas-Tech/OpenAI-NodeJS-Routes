const express = require('express');
const router = express.Router();

const controller = require("./controllers")

// ====================================================================
//                           ChatGPT Embedding Router(s)
// ====================================================================

// Route for Embeddings
router.post('/get-embedding', controller.GetEmbedding);
router.post('/create-embedding', controller.CreateEmbedding);

// ====================================================================

module.exports = router;
