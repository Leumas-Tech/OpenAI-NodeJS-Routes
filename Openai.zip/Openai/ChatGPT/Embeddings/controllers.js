const {openai} = require("../../openai")
const fs = require('fs');

// Embeddings

exports.GetEmbedding = async (req, res) => {
    try {
        const { input, model } = req.body;

        if (!input || !model) {
            return res.status(400).send({
                message: "Input and model fields are required!"
            });
        }

        const openaiResponse = await axios.post('https://api.openai.com/v1/embeddings', {
            input: input,
            model: model
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
            }
        });

        // Send the response from OpenAI back to your client
        res.status(200).send(openaiResponse.data);
    } catch (err) {
        console.error("Error fetching embedding:", err.message);
        res.status(500).send({
            message: "Error fetching embedding"
        });
    }
};



exports.CreateEmbedding = async (req, res) => {
    try {
        const { model, input } = req.body;

        if (!model || !input) {
            return res.status(400).send({
                message: "Model and input fields are required!"
            });
        }

        const embeddingResponse = await openai.embeddings.create({
            model: model,
            input: input,
        });

        // Send the embedding response from OpenAI back to your client
        res.status(200).send(embeddingResponse);

    } catch (err) {
        console.error("Error with create embedding:", err.message);
        res.status(500).send({
            message: "Error with create embedding"
        });
    }
};