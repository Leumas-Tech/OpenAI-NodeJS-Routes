const {openai} = require("../../openai")

exports.CreateModeration = async (req, res) => {
    const inputText = req.body.input;

    if (!inputText) {
        return res.status(400).send({ message: "Input text is required." });
    }

    try {
        const moderation = await openai.moderations.create({ input: inputText });
        res.status(200).send(moderation);
    } catch (err) {
        console.error("Error creating moderation:", err.message);
        res.status(500).send({ message: "Error creating moderation" });
    }
};
