const express = require('express');
const router = express.Router();

const controller = require("./controllers")

// ====================================================================
//                           ChatGPT Moderations Router(s)
// ====================================================================

router.post('/moderations', controller.CreateModeration);

// ====================================================================

module.exports = router;
