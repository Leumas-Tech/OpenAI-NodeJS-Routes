const {openai} = require("../../openai")

exports.ListModels = async (req, res) => {
    try {
        const list = await openai.models.list();
        const models = [];
        for await (const model of list) {
            models.push(model);
        }
        res.status(200).send(models);
    } catch (err) {
        console.error("Error listing models:", err.message);
        res.status(500).send({ message: "Error listing models" });
    }
};


exports.RetrieveModel = async (req, res) => {
    const modelId = req.params.id;

    try {
        const model = await openai.models.retrieve(modelId);
        res.status(200).send(model);
    } catch (err) {
        console.error("Error retrieving model:", err.message);
        res.status(500).send({ message: "Error retrieving model" });
    }
};