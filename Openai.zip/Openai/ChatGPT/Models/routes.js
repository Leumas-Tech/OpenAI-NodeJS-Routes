const express = require('express');
const router = express.Router();

const controller = require("./controllers")


// ====================================================================
//                           ChatGPT Models Router(s)
// ====================================================================

router.get('/', controller.ListModels);
router.get('/models/:id', controller.RetrieveModel);


// ====================================================================

module.exports = router;
