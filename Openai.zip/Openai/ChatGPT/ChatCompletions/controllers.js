const {openai} = require("../../openai")
const fs = require('fs');

exports.ChatCompletion = async (req, res) => {
    try {
        const model = req.body.model || "gpt-3.5-turbo";
        let messages = req.body.messages;

        if (!messages) {
            messages = [
                { "role": "system", "content": "You are a helpful assistant." },
                { "role": "user", "content": "Who won the world series in 2020?" },
                { "role": "assistant", "content": "The Los Angeles Dodgers won the World Series in 2020." },
                { "role": "user", "content": "Where was it played?" }
            ];
        }

        const response = await openai.chat.completions.create({
            messages: messages,
            model: model,
            // max_tokens: 4096 // specify max tokens here, adjust the number as needed
        });

        console.log(response.choices[0].message || "no response")
        if (response && response.choices && response.choices[0] && response.choices[0].message) {
            response.choices[0].message.role = "leviathan ai";
            response.choices[0].message.content = response.choices[0].message.content;
            res.status(200).json(response);
        } else {
            console.error('Invalid structure in OpenAI response or no choices available.');
            res.status(500).json({ message: 'Invalid structure in OpenAI response or no choices available.' });
        }

    } catch (error) {
        console.error('Error during GPT-3.5 Turbo chat completion:', error);
        res.status(500).json({ message: 'Error while fetching completion from GPT-3.5 Turbo' });
    }
};

exports.ChatCompletionStreaming = async (req, res) => {
    try {
        const { model, messages } = req.body;

        if (!model || !messages) {
            return res.status(400).send({
                message: "Model and messages fields are required!"
            });
        }

        const completionStream = await openai.chat.completions.create({
            model: model,
            messages: messages,
            stream: true,
        });

        let responseChunks = [];

        for await (const chunk of completionStream) {
            responseChunks.push(chunk.choices[0].delta.content);
        }

        // Send the response chunks as an array or you can handle it differently
        res.status(200).send(responseChunks);

    } catch (err) {
        console.error("Error with chat completion streaming:", err.message);
        res.status(500).send({
            message: "Error with chat completion streaming"
        });
    }
};