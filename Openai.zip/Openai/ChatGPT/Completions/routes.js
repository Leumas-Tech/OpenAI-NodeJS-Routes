const express = require('express');
const router = express.Router();

const controller = require("./controllers")

// ====================================================================
//                           ChatGPT Completions Router(s)
// ====================================================================

router.post('/completion', controller.Completion);
router.post('/create-completion-streaming', controller.CreateCompletionStreaming);

// ====================================================================

module.exports = router;
