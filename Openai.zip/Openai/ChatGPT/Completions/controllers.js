const {openai} = require("../../openai")
const fs = require('fs');

exports.Completion = async (req, res) => {
    try {
        const model = req.body.model;
        const messages = req.body.messages; // Assuming you'll send an array of messages with their roles

        const response = await openai.chat.completions.create({
            model: model,
            messages: messages,
        });

        console.log(JSON.stringify(response, null, 2));  // Log the full response to debug if needed

        // Extract message content from the response and send it back
        res.status(200).json({ message: response.data.choices[0].message.content.trim() });

    } catch (error) {
        console.error('Error during GPT-3.5 Turbo completion:', error);
        res.status(500).json({ message: 'Error while fetching completion from GPT-3.5 Turbo' });
    }
};


exports.CreateCompletionStreaming = async (req, res) => {
    try {
        const { model, prompt } = req.body;

        if (!model || !prompt) {
            return res.status(400).send({
                message: "Model and prompt fields are required!"
            });
        }

        const completionStream = await openai.completions.create({
            model: model,
            prompt: prompt,
            stream: true,
        });

        let responseChunks = [];

        for await (const chunk of completionStream) {
            responseChunks.push(chunk.choices[0].text);
        }

        // Send the response chunks as an array or you can handle it differently
        res.status(200).send(responseChunks);

    } catch (err) {
        console.error("Error with create completion streaming:", err.message);
        res.status(500).send({
            message: "Error with create completion streaming"
        });
    }
};

