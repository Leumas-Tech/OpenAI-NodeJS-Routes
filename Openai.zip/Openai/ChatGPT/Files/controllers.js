const {openai} = require("../../openai")
const fs = require('fs');
const path = require('path');



exports.ListFiles = async (req, res) => {
    try {
        const files = await openai.files.list();
        res.status(200).send(files);
    } catch (err) {
        console.error("Error listing files:", err.message);
        res.status(500).send({ message: "Error listing files" });
    }
};
exports.UploadFile = async (req, res) => {
    console.log("Entered UploadFile function");

    if (!req.file) {
        console.log("No file detected");
        return res.status(400).send({ message: "File is required!" });
    } else {
        console.log("yes we have a file")
    }

    // Check for file type
    if (req.file.mimetype !== 'application/octet-stream' || !req.file.originalname.endsWith('.jsonl')) {
        console.log("Invalid file type detected");
        return res.status(400).send({ message: "Only .jsonl files are accepted!" });
    }

    try {
        console.log("Attempting to upload to OpenAI...");

        // Create a read stream from the saved file
        const readStream = fs.createReadStream(path.join(__dirname, '..', 'uploads', req.file.filename));

        const file = await openai.files.create({
            file: readStream,
            purpose: "fine-tune ertreter",
        });

        // Close the read stream
        readStream.close();

        // Optionally, delete the temporary file from the server
        fs.unlink(path.join(__dirname, '..', 'uploads', req.file.filename), (err) => {
            if (err) console.error("Error deleting temp file:", err.message);
        });

        console.log("Successfully uploaded:", file);
        res.status(201).send(file);
    } catch (err) {
        console.error("Error uploading file:", err.message);
        res.status(500).send({ message: `Error uploading file: ${err.message}` });
    }    
};


exports.DeleteFile = async (req, res) => {
    const fileId = req.params.fileId;

    try {
        const response = await openai.files.del(fileId);
        res.status(200).send(response);
    } catch (err) {
        console.error("Error deleting file:", err.message);
        res.status(500).send({ message: "Error deleting file" });
    }
};
exports.RetrieveFile = async (req, res) => {
    const fileId = req.params.fileId;

    try {
        const file = await openai.files.retrieve(fileId);
        res.status(200).send(file);
    } catch (err) {
        console.error("Error retrieving file:", err.message);
        res.status(500).send({ message: "Error retrieving file" });
    }
};
exports.RetrieveFileContent = async (req, res) => {
    const fileId = req.params.fileId;

    try {
        const content = await openai.files.retrieveContent(fileId);
        res.status(200).send(content);
    } catch (err) {
        console.error("Error retrieving file content:", err.message);
        res.status(500).send({ message: "Error retrieving file content" });
    }
};
