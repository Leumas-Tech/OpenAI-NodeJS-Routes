const express = require('express');
const router = express.Router();

const controller = require("./controllers");

const multer = require('multer');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });



// ====================================================================
//                           ChatGPT File Router(s)
// ====================================================================

//Files

router.get('/files', controller.ListFiles);

router.post('/upload', upload.single('file'), controller.UploadFile);



router.delete('/files/:fileId', controller.DeleteFile);
router.get('/files/:fileId', controller.RetrieveFile);
router.get('/files/:fileId/content', controller.RetrieveFileContent);

// ====================================================================

module.exports = router;
