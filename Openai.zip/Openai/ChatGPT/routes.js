const express = require('express');
const router = express.Router();

const chatCompletions = require("./ChatCompletions/routes");
const completions = require("./Completions/routes");
const embeddigns = require("./Embeddings/routes");
const files = require("./Files/routes");
const fineTuning = require("./Fine-Tuning/routes");
const models = require("./Models/routes");
const moderations = require("./Moderations/routes");





// ====================================================================
//                          Openai ChatGPT Router(s)
// ====================================================================

router.use("/chat-completions", chatCompletions);

router.use("/completions", completions);

router.use("/embeddigns", embeddigns);

router.use("/files", files);

router.use("/fine-tuning", fineTuning);

router.use("/models", models);

router.use("/moderations", moderations);





// ====================================================================

module.exports = router;
